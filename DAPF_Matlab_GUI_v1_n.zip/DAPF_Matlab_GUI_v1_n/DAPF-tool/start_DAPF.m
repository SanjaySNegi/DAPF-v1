function varargout = start_DAPF(varargin)
% START_DAPF MATLAB code for start_DAPF.fig
%      START_DAPF, by itself, creates a new START_DAPF or raises the existing
%      singleton*.
%
%      H = START_DAPF returns the handle to a new START_DAPF or the handle to
%      the existing singleton*.
%
%      START_DAPF('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in START_DAPF.M with the given input arguments.
%
%      START_DAPF('Property','Value',...) creates a new START_DAPF or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before start_DAPF_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to start_DAPF_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help start_DAPF

% Last Modified by GUIDE v2.5 21-Apr-2020 09:43:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @start_DAPF_OpeningFcn, ...
                   'gui_OutputFcn',  @start_DAPF_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before start_DAPF is made visible.
function start_DAPF_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to start_DAPF (see VARARGIN)

% Choose default command line output for start_DAPF
handles.output = hObject;
handles.path=pwd;
% % filename='start_DAPF';
% % if true
% % fig=gcf;
% % print2eps(filename, fig)
% % % eps2pdf ('DAPF_spectral_analysis1', 'DAPF_spectral_analysis2')
% % movefile '*.eps' 'DAPF_Result'
% % end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes start_DAPF wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = start_DAPF_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1
home_dir= handles.path;
cd (home_dir);
event_num=get(hObject,'Value');
k=num2str(event_num);
set(handles.text3,'String',k);
fil1=getappdata(handles.popupmenu1,'fil1');
folder_path=fil1{event_num};
cd(folder_path);

% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
home_dir= handles.path;
cd (home_dir)
dirct1=dir('*.sta');
for ii=1:numel(dirct1)
p{ii}=dirct1(ii).name;
end
set(handles.popupmenu1,'String',p);
tems = get(handles.popupmenu1,'Value');
filesel=dirct1(tems).name;
% set(handles.edit1,'String',filesel);

dirct1=dir('*.sta');
filesel=dirct1(tems).name;
fid = fopen(filesel);
fil=textscan(fid,'%s','delimiter','\n');
fil1=fil{1};

for jj=1:numel(fil1)
    foldpth=fil1{jj};
   
 if ismac   
out=regexp(foldpth,'/','split');
 elseif isunix
   out=regexp(foldpth,'/','split');
 elseif ispc
     out=regexp(foldpth,'\','split');
     [fPath, fName, fExt] = fileparts(foldpth);
 else
   disp('Platform not supported')
end  
event1{jj}=out{end};

end
tot_event=numel(fil1);
set(handles.listbox1,'String',event1,'Value',1);
setappdata(handles.popupmenu1,'fil1',fil1);



% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%% Generate station-event list
homedir=handles.path;
cd(homedir);
datadir = fullfile(homedir,'DATA');
dirct1=dir(datadir);

stat_lis=dirct1(~ismember({dirct1.name},{'.','..'}));
total_stat=numel(stat_lis);
disp_stat=sprintf('Total stations = %d',total_stat);
set(handles.text2,'String',disp_stat);
% setappdata(handles.pushbutton1,'disp_stat',disp_stat);
for ii=1:numel(stat_lis)
stat_nm=stat_lis(ii).name;
s_nm=sprintf('%s_event_list.sta',stat_nm);
fid=fopen(s_nm,'w');
stat_fold=fullfile(datadir,stat_nm);
ev_lis=dir(stat_fold);
% 
ev_lis=ev_lis(~ismember({ev_lis.name},{'.','..'}));
numb=numel(ev_lis);
for jj=1:numel(ev_lis)
ev_fold=fullfile(stat_fold,ev_lis(jj).name);
fprintf(fid,'%s\n',ev_fold);
end
fclose(fid);
end


% --- Executes during object creation, after setting all properties.
function text2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% disp_stat=getappdata(handles.pushbutton1,'disp_stat');


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
homedir=handles.path;
cd(homedir)
 DAPF


% --- Executes during object creation, after setting all properties.
function text3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% % --- Executes on button press in pushbutton3.
% function pushbutton3_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton3 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% close(DAPF)
% DAPF


% % --- Executes when figure1 is resized.
% function figure1_SizeChangedFcn(hObject, eventdata, handles)
% % hObject    handle to figure1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% set(gcf, 'units', 'normalized', 'position', [0.01 0.15 0.35 0.45]);
