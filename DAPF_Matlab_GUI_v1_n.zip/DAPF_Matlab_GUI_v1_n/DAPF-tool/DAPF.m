
%% The main DAPF-GUI to apply DAta-Adaptive-Polarization-Filter to 3 components seismogram
% Written by: Sanjay. S. Negi (2019)

function varargout = DAPF(varargin)
%DAPF MATLAB code file for untitled2.fig
%      UNTITLED2, by itself, creates a new UNTITLED2 or raises the existing
%      singleton*.
%
%      H = UNTITLED2 returns the handle to a new UNTITLED2 or the handle to
%      the existing singleton*.
%
%      UNTITLED2('Property','Value',...) creates a new UNTITLED2 using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to untitled2_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      UNTITLED2('CALLBACK') and UNTITLED2('CALLBACK',hObject,...) call the
%      local function named CALLBACK in UNTITLED2.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help untitled2

% Last Modified by GUIDE v2.5 16-Apr-2020 01:11:28

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DAPF_OpeningFcn, ...
                   'gui_OutputFcn',  @DAPF_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before untitled2 is made visible.
function DAPF_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for untitled2
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes untitled2 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DAPF_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function browse_button_Callback(hObject, eventdata, handles)
[FileName,FilePath]=uigetfile();
ExPath = [FilePath FileName];
set(handles.answer_edit,'String',ExPath);
guidata(hObject, handles);

%% Start import DATA
%% select N-S component
% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
contents=cellstr(get(hObject,'String'));
pop_choice=contents{get(hObject,'Value')};
if (strcmp(pop_choice,'BHX'))
    list=dir('*.BHX.*');
    sacFile=list.name;
%     disp(sacFile)
else
    if (strcmp(pop_choice,'BHN'))
    list=dir('*.BHN.*');
    sacFile=list.name;
%     disp(sacFile)
    end
end
[dataX,tim_dt,Fs,stat]= readsacdata_for_datetime(sacFile);
axes(handles.axes1);
cla(handles.axes1,'reset');
plot(tim_dt,dataX)

%% Limits of axis
lw_lim1=tim_dt(1);
high_lim1=tim_dt(end);
setappdata(handles.popupmenu1,'lw_lim1',lw_lim1);
setappdata(handles.popupmenu1,'high_lim1',high_lim1);
% set(gca,'XTickLabel',[]);
col = get(gcf, 'color');
set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
axis tight
setappdata(handles.popupmenu1,'dataX',dataX);
setappdata(handles.popupmenu1,'Fs',Fs);
setappdata(handles.popupmenu1,'nscomp',sacFile);
freqe=sprintf('%s',num2str(Fs));
set(handles.Fs_raw,'String',freqe);
dispstat=sprintf('%s',stat);
set(handles.text40,'String',dispstat);



% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, ~, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
    
end



%% Select E-W component
% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2
contents=cellstr(get(hObject,'String'));
pop_choice=contents{get(hObject,'Value')};
if (strcmp(pop_choice,'BHY'))
    list=dir('*.BHY.*');
    sacFile=list.name;
%     disp(sacFile)
    else
    if (strcmp(pop_choice,'BHE'))
    list=dir('*.BHE.*');
    sacFile=list.name;
%     disp(sacFile)
    end
end
[dataY,tim_dt,Fs,~]= readsacdata_for_datetime(sacFile);
axes(handles.axes2);
cla(handles.axes2,'reset');
plot(tim_dt,dataY)
col = get(gcf, 'color');
set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
axis tight
setappdata(handles.popupmenu2,'dataY',dataY);
setappdata(handles.popupmenu2,'ewcomp',sacFile);

% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% Select Z-component
% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu3
contents=cellstr(get(hObject,'String'));
pop_choice=contents{get(hObject,'Value')};
if (strcmp(pop_choice,'BHZ'))
    list=dir('*.BHZ.*');
    sacFile=list.name;
%     disp(sacFile)
end
[dataZ,tim_dt,Fs,~]= readsacdata_for_datetime(sacFile);
axes(handles.axes3);
cla(handles.axes3,'reset');
plot(tim_dt,dataZ)
set(gca, 'box', 'off', 'color', 'none');


axis tight
setappdata(handles.popupmenu3,'dataZ',dataZ);
setappdata(handles.popupmenu3,'zzcomp',sacFile);

% --- Executes during object creation, after setting all properties.
function popupmenu3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% Callback for value K

function K_Callback(hObject, eventdata, handles)
% hObject    handle to K (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of K as text
%        str2double(get(hObject,'String')) returns contents of K as a double


% --- Executes during object creation, after setting all properties.




function K_CreateFcn(hObject, eventdata, handles)
% hObject    handle to K (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% Callback for value g

function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% Callback for Downsample value
function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



%% static text to display Orientation on GUI display
function Orient_Callback(hObject, eventdata, handles)
% hObject    handle to Orient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Orient as text
%        str2double(get(hObject,'String')) returns contents of Orient as a double


% --- Executes during object creation, after setting all properties.
function Orient_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Orient (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%% Callback for the value of orientation angle
function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% Trace length selection 
% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
zzcomp=getappdata(handles.popupmenu3,'zzcomp');
    nscomp=getappdata(handles.popupmenu1,'nscomp');
        ewcomp=getappdata(handles.popupmenu2,'ewcomp');
[dataZZ,tim_dtt,Fs]= readsacdata_for_datetime(zzcomp);
     [dataNS,~,Fs]= readsacdata_for_datetime(nscomp);
         [dataEW,~,Fs]= readsacdata_for_datetime(ewcomp);
cons=get(hObject,'Value');
    setappdata(handles.checkbox1,'cons',cons);

if hObject.Value==1
    pont1=str2num(get(handles.start_time,'String'));
        pont2=str2num(get(handles.stop_time,'String'));
    dt=1/Fs;
    sec2pont1=round(pont1*Fs+1);
        sec2pont2=round(pont2*Fs+1);

    z_cmp=dataZZ(sec2pont1:sec2pont2);
        n_cmp=dataNS(sec2pont1:sec2pont2);
            e_cmp=dataEW(sec2pont1:sec2pont2);
       
tim_dt_old=tim_dtt(sec2pont1:sec2pont2);
%% Get limits of the selected axis and used for DAPF limit plot 
lolim2=tim_dt_old(1);
    highlim2=tim_dt_old(end);
setappdata(handles.checkbox1,'lolim2',lolim2)
    setappdata(handles.checkbox1,'highlim2',highlim2)

axes(handles.axes1);
    cla(handles.axes1,'reset');
        plot(tim_dt_old, n_cmp)
            col = get(gcf, 'color');
                set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                    axis tight
axes(handles.axes2);
    cla(handles.axes2,'reset');
        plot(tim_dt_old,e_cmp)
            col = get(gcf, 'color');
                set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                    axis tight

axes(handles.axes3);
    cla(handles.axes3,'reset');
        plot(tim_dt_old, z_cmp)
            set(gca, 'box', 'off',  'color', 'none');
                axis tight

setappdata(handles.checkbox1,'n_cmp',n_cmp);
    setappdata(handles.checkbox1,'e_cmp',e_cmp);
        setappdata(handles.checkbox1,'z_cmp',z_cmp);
            setappdata(handles.checkbox1,'tim_dt_old',tim_dt_old);
                setappdata(handles.checkbox1,'Fs',Fs);
else
    axes(handles.axes1);
        cla(handles.axes1,'reset');
            plot(tim_dtt,dataNS)
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        axis tight
axes(handles.axes2);
    cla(handles.axes2,'reset');
        plot(tim_dtt,dataEW)
            col = get(gcf, 'color');
                set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
axis tight
    axes(handles.axes3);
        cla(handles.axes3,'reset');
            plot(tim_dtt,dataZZ)
                set(gca, 'box', 'off', 'color', 'none');
                    axis tight
end    


function start_time_Callback(hObject, eventdata, handles)
% hObject    handle to start_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of start_time as text
%        str2double(get(hObject,'String')) returns contents of start_time as a double


% --- Executes during object creation, after setting all properties.
function start_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function stop_time_Callback(hObject, eventdata, handles)
% hObject    handle to stop_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of stop_time as text
%        str2double(get(hObject,'String')) returns contents of stop_time as a double


% --- Executes during object creation, after setting all properties.
function stop_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stop_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes during object creation, after setting all properties.
function timebandwidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timebandwidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% axes(handles.axes2);
% plot(J)


% --- Executes on slider movement.
function slider2_Callback(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
val=get(hObject,'Value');
    assignin('base','Value',val);
        set(handles.start,'String',num2str(val));
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function slider2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of start as text
%        str2double(get(hObject,'String')) returns contents of start as a double
val = str2double(get(hObject,'String'));
    set(handles.slider2,'Value',val);
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function start_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider3_Callback(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
val=get(hObject,'Value');
    assignin('base','Value',val);
        set(handles.stop,'String',num2str(val));
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function slider3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of stop as text
%        str2double(get(hObject,'String')) returns contents of stop as a double
val = str2double(get(hObject,'String'));
set(handles.slider3,'Value',val);
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function stop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on slider movement.
function slider4_Callback(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

maxSliderValue = get(handles.slider4, 'Max');
    minSliderValue = get(handles.slider4, 'Min');
        theRange = maxSliderValue - minSliderValue;
            steps = [1/theRange, 10/theRange];
                set(handles.slider4, 'SliderStep', steps);
                    val=get(hObject,'Value');
                        assignin('base','Value',val);
                            set(handles.edit21,'String',num2str(val));
guidata(hObject,handles)




% --- Executes during object creation, after setting all properties.
function slider4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



%%% Signal start window
% --- Executes during object creation, after setting all properties.
function text22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called




function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double
val = str2double(get(hObject,'String'));
set(handles.slider4,'Value',val);
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end





function Fl_Callback(hObject, eventdata, handles)
% hObject    handle to Fl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fl as text
%        str2double(get(hObject,'String')) returns contents of Fl as a double


% --- Executes during object creation, after setting all properties.
function Fl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FH_Callback(hObject, eventdata, handles)
% hObject    handle to FH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FH as text
%        str2double(get(hObject,'String')) returns contents of FH as a double


% --- Executes during object creation, after setting all properties.
function FH_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FH (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Order_Callback(hObject, eventdata, handles)
% hObject    handle to Order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Order as text
%        str2double(get(hObject,'String')) returns contents of Order as a double


% --- Executes during object creation, after setting all properties.
function Order_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%% Selection to Apply bandpass to input data
% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3
flow=str2num(get(handles.Fl,'String'));
    fhigh=str2num(get(handles.FH,'String'));
        Order=str2num(get(handles.Order,'String'));
            cons1=getappdata(handles.checkbox1,'cons');   %%% condition if data has range
                TNOI1=getappdata(handles.pushbutton1,'TNOI1');
                    TNOI2=getappdata(handles.pushbutton1,'TNOI2');


if cons1==1
    dataNS=getappdata(handles.checkbox1,'n_cmp');   %%% condition if data has range
        dataEW=getappdata(handles.checkbox1,'e_cmp');   %%% condition if data has range
            dataZZ=getappdata(handles.checkbox1,'z_cmp');   %%% condition if data has range

tim_dtt=getappdata(handles.checkbox1,'tim_dt_old');   %%% condition if data has range
    Fs=getappdata(handles.checkbox1,'Fs');   %%% condition if data has range

if hObject.Value==1
    ZZ_BP_FIL=band_pass(dataZZ,Fs,Order,flow,fhigh);
        NS_BP_FIL=band_pass(dataNS,Fs,Order,flow,fhigh);
            EW_BP_FIL=band_pass(dataEW,Fs,Order,flow,fhigh);

axes(handles.axes1);
        cla(handles.axes1,'reset');
            plot(tim_dtt,NS_BP_FIL)
                phs_mark(tim_dtt);
                    col = get(gcf, 'color');
                        set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                            axis 'tight'
                                zoom 'on'
    
axes(handles.axes2);
        cla(handles.axes2,'reset');
            plot(tim_dtt,EW_BP_FIL)
                phs_mark(tim_dtt);
                    col = get(gcf, 'color');
                        set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                            axis tight
                                zoom 'on'
axes(handles.axes3);
        cla(handles.axes3,'reset');
            plot(tim_dtt,ZZ_BP_FIL)
                phs_mark(tim_dtt);
                    col = get(gcf, 'color');
                        set(gca, 'box', 'off',  'color', 'none');    
                            axis tight
                                zoom 'on'
else
axes(handles.axes1);
    cla(handles.axes1,'reset');
        plot(tim_dtt,dataNS)
            col = get(gcf, 'color');
                set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');  
                    phs_mark(tim_dtt);
                        axis tight
                            zoom 'on'
axes(handles.axes2);
    cla(handles.axes2,'reset');
        plot(tim_dtt,dataEW)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');  
                        axis tight
                            zoom 'on'
axes(handles.axes3);
    cla(handles.axes3,'reset');
        plot(tim_dtt,dataZZ)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'color', 'none');  
                        axis tight
                            zoom 'on'
end

else

nscomp=getappdata(handles.popupmenu1,'nscomp');
    ewcomp=getappdata(handles.popupmenu2,'ewcomp');
        zzcomp=getappdata(handles.popupmenu3,'zzcomp');

[dataZZ,tim_dtt1,Fs]= readsacdata_for_datetime(zzcomp);
    [dataNS,~,Fs]= readsacdata_for_datetime(nscomp);
        [dataEW,~,Fs]= readsacdata_for_datetime(ewcomp);

if hObject.Value==1

NS_BP_FIL=band_pass(dataNS,Fs,Order,flow,fhigh);
    EW_BP_FIL=band_pass(dataEW,Fs,Order,flow,fhigh);
        ZZ_BP_FIL=band_pass(dataZZ,Fs,Order,flow,fhigh);

axes(handles.axes1);
    cla(handles.axes1,'reset');
        plot(tim_dtt1,NS_BP_FIL)
            phs_mark(tim_dtt1);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        axis tight
                            zoom 'on'
axes(handles.axes2);
    cla(handles.axes2,'reset');
        plot(tim_dtt1,EW_BP_FIL)
            phs_mark(tim_dtt1);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        axis tight
                            zoom 'on'
axes(handles.axes3);
    cla(handles.axes3,'reset');
        plot(tim_dtt1,ZZ_BP_FIL)
            phs_mark(tim_dtt1);
                set(gca, 'box', 'off',  'color', 'none');
                    axis tight
                        zoom 'on'
else
axes(handles.axes1);
    cla(handles.axes1,'reset');
        plot(tim_dtt1,dataNS)
            phs_mark(tim_dtt1);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        axis tight
                            zoom 'on'
axes(handles.axes2);
    cla(handles.axes2,'reset');
        plot(tim_dtt1,dataEW)
            phs_mark(tim_dtt1);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        axis tight
                            zoom 'on'
axes(handles.axes3);
    cla(handles.axes3,'reset');
        plot(tim_dtt1,dataZZ)
            phs_mark(tim_dtt1);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'color', 'none');
                        axis tight
                            zoom 'on'
end

end

%% Selection to apply bandpass to DAPF output
% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

flow=str2num(get(handles.Fl,'String'));
    fhigh=str2num(get(handles.FH,'String'));
        Order=str2num(get(handles.Order,'String'));

dataZZ=getappdata(handles.pushbutton1,'Tr_new1');
    dataNS=getappdata(handles.pushbutton1,'Tr_new2');
        dataEW=getappdata(handles.pushbutton1,'Tr_new3');
tim_dtt=getappdata(handles.pushbutton1,'tim_dt');
    Fs=getappdata(handles.pushbutton1,'Fs');
        tlim1=getappdata(handles.pushbutton1,'tlim1');
            tlim2=getappdata(handles.pushbutton1,'tlim2');

TNOI1=getappdata(handles.pushbutton1,'TNOI1');
    TNOI2=getappdata(handles.pushbutton1,'TNOI2');

%% limit for cut data
cons=getappdata(handles.checkbox1,'cons');
    lox2=getappdata(handles.checkbox1,'lolim2');
        hix2=getappdata(handles.checkbox1,'highlim2');
if cons==1
% Hint: get(hObject,'Value') returns toggle state of checkbox4
if hObject.Value==1
    ZZ_BP_DAPF=band_pass(dataZZ,Fs,Order,flow,fhigh);
        NS_BP_DAPF=band_pass(dataNS,Fs,Order,flow,fhigh);
            EW_BP_DAPF=band_pass(dataEW,Fs,Order,flow,fhigh);
axes(handles.axes4);
 cla(handles.axes4,'reset');
    plot(tim_dtt,NS_BP_DAPF)
        phs_mark(tim_dtt);
            col = get(gcf, 'color');
                set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                    zoom 'on'
                        xlim([lox2 hix2])
axes(handles.axes5);
 cla(handles.axes5,'reset');
    plot(tim_dtt,EW_BP_DAPF)
       phs_mark(tim_dtt);
        col = get(gcf, 'color');
            set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                zoom 'on'
                    xlim([lox2 hix2])
axes(handles.axes6);
  cla(handles.axes6,'reset');
    plot(tim_dtt,ZZ_BP_DAPF)
      phs_mark(tim_dtt);
        set(gca, 'box', 'off', 'color', 'none');
            zoom 'on'
                xlim([lox2 hix2])
else
   
axes(handles.axes4);
    cla(handles.axes4,'reset');
        plot(tim_dtt,dataNS)
            phs_mark(tim_dtt);
               col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([lox2 hix2])
axes(handles.axes5);
    cla(handles.axes5,'reset');
        plot(tim_dtt,dataEW)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([lox2 hix2])
axes(handles.axes6);
    cla(handles.axes6,'reset');
        plot(tim_dtt,dataZZ)
            phs_mark(tim_dtt);
                set(gca, 'box', 'off', 'color', 'none');
                    zoom 'on'
                        xlim([lox2 hix2])
end

else
    
    if hObject.Value==1
        ZZ_BP_DAPF=band_pass(dataZZ,Fs,Order,flow,fhigh);
            NS_BP_DAPF=band_pass(dataNS,Fs,Order,flow,fhigh);
                EW_BP_DAPF=band_pass(dataEW,Fs,Order,flow,fhigh);
axes(handles.axes4);
    cla(handles.axes4,'reset');
        plot(tim_dtt,NS_BP_DAPF)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
axes(handles.axes5);
    cla(handles.axes5,'reset');
        plot(tim_dtt,EW_BP_DAPF)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
axes(handles.axes6);
    cla(handles.axes6,'reset');
        plot(tim_dtt,ZZ_BP_DAPF)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
else
   
axes(handles.axes4);
    cla(handles.axes4,'reset');
        plot(tim_dtt,dataNS)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
axes(handles.axes5);
    cla(handles.axes5,'reset');
        plot(tim_dtt,dataEW)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
axes(handles.axes6);
    cla(handles.axes6,'reset');
        plot(tim_dtt,dataZZ)
            phs_mark(tim_dtt);
                col = get(gcf, 'color');
                    set(gca, 'box', 'off', 'color', 'none');
                        zoom 'on'
                            xlim([tlim1 tlim2])
    end
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% J = getappdata(handles.popupmenu1,'dataX');

fprintf('Processing started ...\n')


%%
zzcomp=getappdata(handles.popupmenu3,'zzcomp');
    nscomp=getappdata(handles.popupmenu1,'nscomp');
        ewcomp=getappdata(handles.popupmenu2,'ewcomp');

K=str2num(get(handles.K,'String'));
    g=str2num(get(handles.edit2,'String'));
        fact=str2num(get(handles.edit4,'String'));
            phi=str2num(get(handles.edit8,'String'));
                dec_rng=get(handles.checkbox1,'value');
                    pont1=str2num(get(handles.start_time,'String'));
                        pont2=str2num(get(handles.stop_time,'String'));
%%%% noise window
tn1=str2double(get(handles.start,'String'));
    tn2=str2double(get(handles.stop,'String'));
        t1=str2double(get(handles.text22,'String'));
            t2=str2double(get(handles.edit21,'String'));

or_dtnm=ort_detail;

%% Store to sac format  % <------------------
%%% For origin time this value is zero. 
store_sac=1;  %% handle to store the sac data default is 'store_sac=0'. 
              % % if save output in sac format then 'store_sac=1';


%% Calls DAPF function file
use_land=getappdata(handles.Landdata,'use_land');
    use_OBS=getappdata(handles.OBSdata,'use_OBS');
        dwnsmpl=getappdata(handles.Downsample,'dwnsmpl');

[Tr_new1,Tr_new2,Tr_new3,tim_dt,Fs,TNOI1,TNOI2]=DAPF_mul_tap_pmtm(zzcomp,nscomp,ewcomp, ...
    K,g,t1,t2,tn1,tn2,phi,fact,dec_rng,pont1,pont2,store_sac,or_dtnm,dwnsmpl,use_land,use_OBS); 


%% To display time arrival info
tim_arri = readtable('arrival_time.txt');
    dis_k=tim_arri;
        hd={'Phase','arrivaltime'}; 
            dis_k.Properties.VariableNames=hd; % setting the second row as header 
                disp(dis_k)
%%	
setappdata(handles.pushbutton1,'TNOI2',TNOI2);
    setappdata(handles.pushbutton1,'TNOI1',TNOI1);
        tlim1=tim_dt(1);
            tlim2=tim_dt(end);

setappdata(handles.pushbutton1,'tlim1',tlim1);
    setappdata(handles.pushbutton1,'tlim2',tlim2);

freqe=sprintf('%s',num2str(Fs));
    set(handles.text38,'String',freqe);
        set(handles.text48, 'String', '');
            set(handles.text48,'String','Job finished !!','ForegroundColor','Blue');


%% Plot DAPF result on gui
%% limit for full data
lox1=getappdata(handles.popupmenu1,'lw_lim1');
    hix1=getappdata(handles.popupmenu1,'high_lim1');

%% limit for cut data
cons=getappdata(handles.checkbox1,'cons');
    lox2=getappdata(handles.checkbox1,'lolim2');
        hix2=getappdata(handles.checkbox1,'highlim2');

if cons==1
% Plot N-S component
axes(handles.axes4);
    cla(handles.axes4,'reset');
        plot(tim_dt,Tr_new2)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        col = get(gcf, 'color');
                            set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                                zoom 'on'
                                    xlim([lox2 hix2])
% Plot E-W component
axes(handles.axes5);
    cla(handles.axes5,'reset');
        plot(tim_dt,Tr_new3)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        col = get(gcf, 'color');
                            set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                                zoom 'on'
                                    xlim([lox2 hix2])


%Plot Z-Comp

axes(handles.axes6);
    cla(handles.axes6,'reset');
        plot(tim_dt,Tr_new1)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        set(gca, 'box', 'off','color', 'none');
                            zoom 'on'
                                xlim([lox2 hix2])

setappdata(handles.pushbutton1,'Tr_new1',Tr_new1);  %% Z component
    setappdata(handles.pushbutton1,'Tr_new2',Tr_new2);
        setappdata(handles.pushbutton1,'Tr_new3',Tr_new3);
            setappdata(handles.pushbutton1,'tim_dt',tim_dt);
                setappdata(handles.pushbutton1,'Fs',Fs);
else
    
axes(handles.axes4);
    cla(handles.axes4,'reset');
        plot(tim_dt,Tr_new2)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        col = get(gcf, 'color');
                            set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                                zoom 'on'
                                    xlim([lox1 hix1])
axes(handles.axes5);
    cla(handles.axes5,'reset');
        plot(tim_dt,Tr_new3)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        col = get(gcf, 'color');
                            set(gca, 'box', 'off', 'xtick', [], 'xcolor', col, 'color', 'none');
                                zoom 'on'
                                    xlim([lox1 hix1])

axes(handles.axes6);
    cla(handles.axes6,'reset');
        plot(tim_dt,Tr_new1)
            phs_mark(tim_dt);
                plot([TNOI1 TNOI1], ylim,'--r');
                    plot([TNOI2 TNOI2], ylim,'--r');
                        set(gca, 'box', 'off','color', 'none');
                            zoom 'on'
                                xlim([lox1 hix1])

setappdata(handles.pushbutton1,'Tr_new1',Tr_new1);
    setappdata(handles.pushbutton1,'Tr_new2',Tr_new2);
        setappdata(handles.pushbutton1,'Tr_new3',Tr_new3);
            setappdata(handles.pushbutton1,'tim_dt',tim_dt);
                setappdata(handles.pushbutton1,'Fs',Fs);

end

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if hObject.Value==1
    lml=str2num(get(handles.Fl,'String'));
        hml=str2num(get(handles.FH,'String'));
            Order=str2num(get(handles.Order,'String'));
                tf=str2num(get(handles.tick_frequency,'String'));
    
bp_analysis_ORIG(lml,hml,Order,tf);
    
end



function tick_frequency_Callback(hObject, eventdata, handles)
% hObject    handle to tick_frequency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tick_frequency as text
%        str2double(get(hObject,'String')) returns contents of tick_frequency as a double


% --- Executes during object creation, after setting all properties.
function tick_frequency_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tick_frequency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function Fs_raw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fs_raw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Fs=getappdata(handles.popupmenu1,'Fs')
% set(handles.Fs_raw,'String',num2str(Fs));
% guidata(hObject,handles)





% --- Executes on button press in Downsample.
function Downsample_Callback(hObject, eventdata, handles)
% hObject    handle to Downsample (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Downsample
dwnsmpl=get(hObject,'Value');
setappdata(handles.Downsample,'dwnsmpl',dwnsmpl);


% --- Executes on button press in Landdata.
function Landdata_Callback(hObject, eventdata, handles)
% hObject    handle to Landdata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of Landdata
use_land=get(hObject,'Value');
setappdata(handles.Landdata,'use_land',use_land);


% --- Executes on button press in OBSdata.
function OBSdata_Callback(hObject, eventdata, handles)
% hObject    handle to OBSdata (see GCBO)
% eventdata  reserved - to be dcons1=getappdata(handles.checkbox1,'cons'); efined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of OBSdata
use_OBS=get(hObject,'Value');
setappdata(handles.OBSdata,'use_OBS',use_OBS);


% --- Executes during object creation, after setting all properties.
function text38_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function text40_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text40 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% % --- Executes on button press in pushbutton7.
% function pushbutton7_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton7 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% 
% % --- Executes on button press in pushbutton8.
% function pushbutton8_Callback(hObject, eventdata, handles)
% % hObject    handle to pushbutton8 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
DAPF_spectral_analysis

% --- Executes during object creation, after setting all properties.
function text48_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text48 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% % --- Executes when figure1 is resized.
% function figure1_SizeChangedFcn(hObject, eventdata, handles)
% % hObject    handle to figure1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% set(gcf, 'units', 'normalized', 'position', [0.09 0.15 0.9 0.8]);


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fprintf('\n\nSaving GUI initiated .....\n')
filename='DAPF-GUI';

if true
fig=gcf;
    print2eps(filename, fig);
        movefile '*.eps' 'DAPF_Result';
            fprintf('\nSaved GUI for current view !!\n')
end

% --- Executes during object creation, after setting all properties.
function pushbutton9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(DAPF)
DAPF
