function varargout = DAPF_spectral_analysis(varargin)
% DAPF_SPECTRAL_ANALYSIS MATLAB code for DAPF_spectral_analysis.fig
%      DAPF_SPECTRAL_ANALYSIS, by itself, creates a new DAPF_SPECTRAL_ANALYSIS or raises the existing
%      singleton*.
%
%      H = DAPF_SPECTRAL_ANALYSIS returns the handle to a new DAPF_SPECTRAL_ANALYSIS or the handle to
%      the existing singleton*.
%
%      DAPF_SPECTRAL_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DAPF_SPECTRAL_ANALYSIS.M with the given input arguments.
%
% %      DAPF_SPECTRAL_ANALYSIS('Property','Value',...) creates a new DAPF_SPECTRAL_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DAPF_spectral_analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DAPF_spectral_analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DAPF_spectral_analysis

% Last Modified by GUIDE v2.5 19-Apr-2020 03:25:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DAPF_spectral_analysis_OpeningFcn, ...
                   'gui_OutputFcn',  @DAPF_spectral_analysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DAPF_spectral_analysis is made visible.
function DAPF_spectral_analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DAPF_spectral_analysis (see VARARGIN)

% Choose default command line output for DAPF_spectral_analysis
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DAPF_spectral_analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DAPF_spectral_analysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;





% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% Hint: place code in OpeningFcn to populate axes1
% h1=axes(handles.axes1);




% --- Executes during object creation, after setting all properties.
function axes2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes2
% h2=axes(handles.axes2)

% --- Executes during object creation, after setting all properties.
function axes3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes3
% h3=axes(handles.axes3);



function ovrlp_Callback(hObject, eventdata, handles)
% hObject    handle to ovrlp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ovrlp as text
%        str2double(get(hObject,'String')) returns contents of ovrlp as a double


% --- Executes during object creation, after setting all properties.
function ovrlp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ovrlp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function FR_Callback(hObject, eventdata, handles)
% hObject    handle to FR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of FR as text
%       str2double(get(hObject,'String')) returns contents of FR as a double


% --- Executes during object creation, after setting all properties.
function FR_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FR (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Lkg_Callback(hObject, eventdata, handles)
% hObject    handle to Lkg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Lkg as text
%        str2double(get(hObject,'String')) returns contents of Lkg as a double
L1=str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function Lkg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Lkg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MT_Callback(hObject, eventdata, handles)
% hObject    handle to MT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MT as text
%        str2double(get(hObject,'String')) returns contents of MT as a double


% --- Executes during object creation, after setting all properties.
function MT_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


%%% For BHN component

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cons_ns=get(hObject,'Value');
    setappdata(handles.pushbutton2,'cons_ns',cons_ns);

%%% For BHN component
Ovlp=str2num(get(handles.ovrlp,'String'));
    FreqRes=str2num(get(handles.FR,'String'));
        Lkg=str2num(get(handles.Lkg,'String'));
            MinThr=str2num(get(handles.MT,'String'));


%%%%% Loading original trace details
load 'filt_trace2.mat'; 
load 'Fs.mat'; load 'tim_dt.mat'; load 'comp2.mat';
%%%%% loading AfpPFR trace
load 'Tr_new2.mat'; 
load 't_sec.mat';

filt_trace2=filt_trace2(1:length(Tr_new2));
    tim=tim_dt(1:length(Tr_new2));
        save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new2));
        save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new2));
    save('tim.mat','tim');
        tsec=t_sec(1:length(Tr_new2));
            save('tsec.mat','tsec');

%%%% Power difference
[p1,f1]= pspectrum(filt_trace2,Fs);
[p2,f2]= pspectrum(Tr_new2,Fs);
% % % %% only used in case of synthetic when we add oversampling;
% % % [ d1, ix1 ] = min( abs( f1-0.25 ) )
% % % % [ d2, ix3 ] = min( abs( f2-2.5 ) )
% % % powr_dif=mean((10*log10(p1(1:ix1)) - 10*log10(p2(1:ix1))));
%% Used for normal downsampled case
powr_dif=mean((10*log10(p1) - 10*log10(p2)));
    axes(handles.axes1)
        cla(handles.axes1,'reset');

[pp1,ff1]= pspectrum(filt_trace2,Fs);
    semilogx(ff1,pow2db(pp1))
        hold on
[pp2,ff2]=pspectrum(Tr_new2,Fs);
    semilogx(ff2,pow2db(pp2))

xlabel('Frequency (Hz)')
ylabel('Power Spectrum [dB]')


legend({'Raw Trace','DAPF Trace'},'FontSize',12)
set(get(gca, 'Title'), 'Visible', 'off')
zoom 'on'
box 'on'

axes(handles.axes2)
cla(handles.axes2,'reset');
% pspectrum(filt_trace1,Fs,'spectrogram');
pspectrum(filt_trace2,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr)
set(get(gca, 'Title'), 'Visible', 'off')
db_dif=sprintf('Mean Noise Reduction (dB) = %6.1f',powr_dif);
set(handles.text7,'String',db_dif);
set(handles.text11,'String','Comp-BHN');


axes(handles.axes3)
cla(handles.axes3,'reset');
pspectrum(Tr_new2,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr);

set(get(gca, 'Title'), 'Visible', 'off')
tlim1=tim(1);
tlim2=tim(end);

axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new2); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])
 %  axis tight;

% end



%%% For BHE component


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cons_ew=get(hObject,'Value');
setappdata(handles.pushbutton3,'cons_ew',cons_ew);


%%% For BHE component


Ovlp=str2num(get(handles.ovrlp,'String'));
FreqRes=str2num(get(handles.FR,'String'));
Lkg=str2num(get(handles.Lkg,'String'));
MinThr=str2num(get(handles.MT,'String'));

load 'Fs.mat'; load 'tim_dt.mat';
load 'comp3.mat';
%%%%% Loading original trace
load 'filt_trace3.mat'; 
%%%%% loading AfpPFR trace
load 'Tr_new3.mat'; 
load 't_sec.mat';
% fact=str2num(get(handles.edit8,'String'));

filt_trace3=filt_trace3(1:length(Tr_new3));


%% %%%% time length
tim=tim_dt(1:length(Tr_new3));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new3));
save('tsec.mat','tsec');

%%%% Power difference
[p1,f1]= pspectrum(filt_trace3,Fs);
[p2,f2]= pspectrum(Tr_new3,Fs);
pont=1:8;
powr_dif=mean((10*log10(p1(pont)) - 10*log10(p2(pont))));
save('f1.mat','f1')

% figure(1)
axes(handles.axes1)
cla(handles.axes1,'reset');
[pp1,ff1]= pspectrum(filt_trace3,Fs);
semilogx(ff1,pow2db(pp1))
 hold on
[pp2,ff2]=pspectrum(Tr_new3,Fs);
semilogx(ff2,pow2db(pp2))
xlabel('Frequency (Hz)')
ylabel('Power Spectrum [dB]')
legend({'Raw Trace','DAPF Trace'},'FontSize',12)
set(get(gca, 'Title'), 'Visible', 'off')
zoom 'on'
box 'on'

axes(handles.axes2)
% pspectrum(filt_trace1,Fs,'spectrogram');
pspectrum(filt_trace3,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr)
set(get(gca, 'Title'), 'Visible', 'off')
db_dif=sprintf('Mean Noise Reduction (dB) = %6.1f',powr_dif);
set(handles.text7,'String',db_dif);
set(handles.text11,'String','Comp-BHE');


axes(handles.axes3)
pspectrum(Tr_new3,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr)
set(get(gca, 'Title'), 'Visible', 'off')

tlim1=tim(1);
tlim2=tim(end);
axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new3); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])



%% Processing BHZ Component

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cons_z=get(hObject,'Value');
setappdata(handles.pushbutton1,'cons_z',cons_z);
%%%  Inputs for spectrogram

Ovlp=str2num(get(handles.ovrlp,'String'));
FreqRes=str2num(get(handles.FR,'String'));
Lkg=str2num(get(handles.Lkg,'String'));
MinThr=str2num(get(handles.MT,'String')); 

load 'Fs.mat'; load 'tim_dt.mat';
load 'comp1.mat';
%%%%% Loading original trace
load 'filt_trace1.mat'; 
%%%%% loading AfpPFR trace
load 'Tr_new1.mat'; 
load 't_sec.mat';
% fact=str2num(get(handles.edit8,'String'));
filt_trace1=filt_trace1(1:length(Tr_new1));


%% %%%% time length
tim=tim_dt(1:length(Tr_new1));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new1));
save('tsec.mat','tsec');

%%%% Power difference
p1= pspectrum(filt_trace1,Fs);
p2= pspectrum(Tr_new1,Fs);
powr_dif=mean((10*log10(p1) - 10*log10(p2)));

axes(handles.axes1);
cla(handles.axes1,'reset');

[pp1,ff1]= pspectrum(filt_trace1,Fs);
semilogx(ff1,pow2db(pp1))
 hold on
[pp2,ff2]=pspectrum(Tr_new1,Fs);
semilogx(ff2,pow2db(pp2))
xlabel('Frequency (Hz)')
ylabel('Power Spectrum [dB]')

legend({'Raw Trace','DAPF Trace'},'FontSize',12)
set(get(gca, 'Title'), 'Visible', 'off')
zoom 'on'
box 'on'


axes(handles.axes2)
% pspectrum(filt_trace1,Fs,'spectrogram');
pspectrum(filt_trace1,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr)
set(get(gca, 'Title'), 'Visible', 'off')

db_dif=sprintf('Mean Noise Reduction (dB) = %6.1f',powr_dif);
set(handles.text7,'String',db_dif);

set(handles.text11,'String','Comp-BHZ');


axes(handles.axes3)
% pspectrum(Tr_new1,Fs,'spectrogram');
pspectrum(Tr_new1,Fs,'spectrogram','OverlapPercent',Ovlp,'FrequencyResolution',FreqRes, ...
    'Leakage',Lkg,'MinThreshold',MinThr)
set(get(gca, 'Title'), 'Visible', 'off')

tlim1=tim(1);
tlim2=tim(end);
axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new1); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])


% --- Executes during object creation, after setting all properties.
function text7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'BackgroundColor','white')


% --- Executes during object creation, after setting all properties.
function text11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% set(hObject,'BackgroundColor','white')


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% kon=get(handles.pushbutton1,'Value')
kon=get(handles.text11,'String');
filename=sprintf('DAPF-spectral-analysis-%s',kon);
if true
fig=gcf;
% % fig.InvertHardcopy = 'off';
% % orient(fig,'landscape')
% % set(fig,'PaperPositionMode','auto');
% % %   printpreview(fig)
% % % set(fig,'Position',[10 10 80 120])
% % % saveas(fig,'DAPF_spectral_analysi.pdf.pdf')
% % print(fig,'-dpdf','DAPF_spectral_analysi.pdf')
print2eps(filename, fig)
% eps2pdf ('DAPF_spectral_analysis1', 'DAPF_spectral_analysis2')
movefile '*.eps' 'DAPF_Result'
end

% if true
%  fig= test_gui.fig;
%  fig.InvertHardcopy = 'off';
%  set(fig,'PaperPositionMode','auto');
%  print(fig,'-dpdf','test_gui.pdf')
% end


% --- Executes during object creation, after setting all properties.
function text8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% set(hObject,'BackgroundColor','none')


% --- Executes during object creation, after setting all properties.
function text9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% set(hObject,'BackgroundColor','none')


% --- Executes during object creation, after setting all properties.
function text10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% set(hObject,'BackgroundColor','transparent')


% --- Executes during object creation, after setting all properties.
function axes5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes5


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
% cons1=getappdata(handles.checkbox1,'cons');   %%% condition if data has range
cons1=get(hObject,'Value');

load 'Fs.mat'; load 'tim_dt.mat';
load 'comp2.mat';
%%%%% Loading original trace
load 'filt_trace2.mat'; 
%%%%% loading AfpPFR trace
load 'Tr_new2.mat'; 
load 't_sec.mat';

filt_trace2=filt_trace2(1:length(Tr_new2));
tim=tim_dt(1:length(Tr_new2));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new2));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new2));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new2));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new2));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new2));
save('tsec.mat','tsec');

flow=str2num(get(handles.Fl,'String'));
fhigh=str2num(get(handles.Fh,'String'));
Order=str2num(get(handles.order,'String'));

tlim1=tim(1);
tlim2=tim(end);

if cons1==1

NS=band_pass(Tr_new2,Fs,Order,flow,fhigh);

axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,NS); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])
else
    
 axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new2); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])   
end



function Fl_Callback(hObject, eventdata, handles)
% hObject    handle to Fl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fl as text
%        str2double(get(hObject,'String')) returns contents of Fl as a double


% --- Executes during object creation, after setting all properties.
function Fl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fh_Callback(hObject, eventdata, handles)
% hObject    handle to Fh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fh as text
%        str2double(get(hObject,'String')) returns contents of Fh as a double


% --- Executes during object creation, after setting all properties.
function Fh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function order_Callback(hObject, eventdata, handles)
% hObject    handle to order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of order as text
%        str2double(get(hObject,'String')) returns contents of order as a double


% --- Executes during object creation, after setting all properties.
function order_CreateFcn(hObject, eventdata, handles)
% hObject    handle to order (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%%% APPLY BP ON BHE
% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
cons1=get(hObject,'Value');

load 'Fs.mat'; load 'tim_dt.mat';
load 'comp3.mat';
%%%%% Loading original trace
load 'filt_trace3.mat'; 
%%%%% loading AfpPFR trace
load 'Tr_new3.mat'; 
load 't_sec.mat';
% fact=str2num(get(handles.edit8,'String'));
filt_trace3=filt_trace3(1:length(Tr_new3));
tim=tim_dt(1:length(Tr_new3));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new3));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new3));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new3));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new3));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new3));
save('tsec.mat','tsec');

flow=str2num(get(handles.Fl,'String'));
fhigh=str2num(get(handles.Fh,'String'));
Order=str2num(get(handles.order,'String'));

tlim1=tim(1);
tlim2=tim(end);

if cons1==1

EW=band_pass(Tr_new3,Fs,Order,flow,fhigh);

axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,EW); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])
else
    
 axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new3); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])   
end


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3

cons1=get(hObject,'Value');

load 'Fs.mat'; load 'tim_dt.mat';
load 'comp1.mat';
%%%%% Loading original trace
load 'filt_trace1.mat'; 
%%%%% loading AfpPFR trace
load 'Tr_new1.mat'; 
load 't_sec.mat';
% fact=str2num(get(handles.edit8,'String'));
filt_trace1=filt_trace1(1:length(Tr_new1));
tim=tim_dt(1:length(Tr_new1));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new1));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new1));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new1));
save('tsec.mat','tsec');


%% %%%% time length
tim=tim_dt(1:length(Tr_new1));
save('tim.mat','tim');

tsec=t_sec(1:length(Tr_new1));
save('tsec.mat','tsec');

flow=str2num(get(handles.Fl,'String'));
fhigh=str2num(get(handles.Fh,'String'));
Order=str2num(get(handles.order,'String'));

tlim1=tim(1);
tlim2=tim(end);

if cons1==1

ZZ=band_pass(Tr_new1,Fs,Order,flow,fhigh);

axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,ZZ); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])
else
    
 axes(handles.axes5)
cla(handles.axes5,'reset');
% plot(tsec/60,Tr_new2); axis tight;
plot(tim,Tr_new1); axis tight;
hold on
phs_mark(tim)
 xlim([tlim1 tlim2])   
end


% % --- Executes when figure1 is resized.
% function figure1_SizeChangedFcn(hObject, eventdata, handles)
% % hObject    handle to figure1 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% set(gcf, 'units', 'normalized', 'position', [0.05 0.15 0.9 0.8])

% 
% % --- Executes on button press in dwn.
% function dwn_Callback(hObject, eventdata, handles)
% % hObject    handle to dwn (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hint: get(hObject,'Value') returns toggle state of dwn
% dwnsmpl=get(hObject,'Value')
% setappdata(handles.dwn,'dwnsmpl',dwnsmpl);
% 
% 
% function edit8_Callback(hObject, eventdata, handles)
% % hObject    handle to edit8 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: get(hObject,'String') returns contents of edit8 as text
% %        str2double(get(hObject,'String')) returns contents of edit8 as a double
% 
% 
% % --- Executes during object creation, after setting all properties.
% function edit8_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to edit8 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
% 
% 
% 
% function edit9_Callback(hObject, eventdata, handles)
% % hObject    handle to edit9 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% 
% % Hints: get(hObject,'String') returns contents of edit9 as text
% %        str2double(get(hObject,'String')) returns contents of edit9 as a double
% 
% 
% % --- Executes during object creation, after setting all properties.
% function edit9_CreateFcn(hObject, eventdata, handles)
% % hObject    handle to edit9 (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    empty - handles not created until after all CreateFcns called
% 
% % Hint: edit controls usually have a white background on Windows.
% %       See ISPC and COMPUTER.
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
