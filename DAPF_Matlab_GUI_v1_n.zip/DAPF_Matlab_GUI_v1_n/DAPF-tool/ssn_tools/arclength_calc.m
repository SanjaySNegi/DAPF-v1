% The script 'arclength_calc' estimates source-receiver distance in
% degrees.

% Input- Event- latitude longitude and depth
%        Station- latitude, longitude 
%        
% Output- 'arcdist.txt'
% Written by: Sanjay. S. Negi (2019)

function arclength_calc(lat_ev,long_ev,dep_ev,stla,stlo,stat)


%% EQ details
lat_eq= lat_ev;	
lon_eq= long_ev; 	
dp_eq=dep_ev;
fid=fopen('arcdist.txt','w');
% for ii=1:length(OBS_num)
    lat_st=stla;
    lon_st=stlo;
[arclen,az] = distance(lat_st,lon_st,lat_eq,lon_eq);
fprintf(fid,'earthquake with lat=%7.4f, lon=%7.4f, and depth=%3.0f km is %7.4f degree epicentral distance from OBS-%02.0f\n',lat_eq,lon_eq,dp_eq,arclen,stat);
