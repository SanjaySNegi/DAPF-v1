%%%%%%%%%%Multitaper filtering (MF) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% The script mul_tap_fft applies the multitaper fast fourier transform to
%%% the input time series data.

% Input: Seismogram trace, nw (time_halfbandwidth) and sampling rate 
% Output: Multitapered discrete fourier transform.
% Written by: Sanjay. S. Negi (2019)

function [z,avg_z,dps_seq,num_seq,seq_length]=mul_tap_fft(Tr,nw,dt)


l_tr=length(Tr);

% nw=2.5; %% MF inputs
    seq_length = l_tr; 
        num_seq = 2*(nw)-1;
   [dps_seq] = dpss(seq_length,nw,num_seq);
   z=zeros(seq_length,num_seq);    


for aa=1:num_seq
    mul_Tr=Tr.*dps_seq(:,aa);
      z(:,aa)=fft(mul_Tr)*dt;        
   
end

%%%% Adding all slepian sequence of multi-tapered fft and averaging
 k=zeros(seq_length,1);

for jj=1:num_seq
    k=z(:,jj)+k;
    
end
         avg_z=k/num_seq; 
      
end
