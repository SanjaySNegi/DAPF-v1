function [ filt_trace1, filt_trace2,filt_trace3]=filt_analysis(out1,out2,out3,Fs,low_lim,high_lim,order)
     
%%%% Band-pass Filtering

          filt_trace1=band_pass(out1,Fs,order,low_lim,high_lim);
      filt_trace2=band_pass(out2,Fs,order,low_lim,high_lim);
   filt_trace3=band_pass(out3,Fs,order,low_lim,high_lim);
end