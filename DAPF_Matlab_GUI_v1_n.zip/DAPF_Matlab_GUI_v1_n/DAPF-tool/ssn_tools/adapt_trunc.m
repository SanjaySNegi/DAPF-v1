%%%% Adaptive truncation (Du et al., 2000)
%%%% Written by: Sanjay. S. Negi (2019) 


function [valm,indm]=adapt_trunc(pol,g,K,l_N,l_out,dt)

%%%%% Here the output is 
%%%%% valm= minimum difference of the value with 0.8 criterion
%%%%% and indm is the


omeg1=0;
for l=0:(l_N-1)/2
   gib2=0;
for m=1:l_N/2-1
% % gib2=gib2+(pol^g+((1-pol^g)*K/(sqrt(2)*l_N))*exp(-pi/2*(l/(l_out-m))^2*K^2));
gib2=gib2+(exp((-pi/2)*(l/(l_out-m))^2*K^2));

end
omeg1=omeg1+(pol^g+((1-pol^g)*(K/(sqrt(2)*l_N))))*gib2;
% ome(l+1)=omeg1;
end
% semilogy(ome)
% return
comprt=0.8;
omeg2=0;
% s=0;
for l=0:l_N
    del=(l+1-l)*(l_N*dt)^-1;
    gib2k=0;
for m=1:l_N/2-1
gib2k=gib2k+(exp((-pi/2)*(l/(l_out-m))^2*K^2));
end
omeg2=omeg2+((pol^g*del)+((1-pol^g)*K/(sqrt(2)*l_N)))*gib2k;
rat=gib2k/omeg2;
rat_min(l+1)=abs(rat-comprt);
[valm,indm]=min(rat_min);

end

end