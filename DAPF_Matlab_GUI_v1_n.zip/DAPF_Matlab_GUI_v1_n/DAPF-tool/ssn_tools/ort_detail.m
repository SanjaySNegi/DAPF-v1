function or_dtnm=ort_detail
%% Origin-time details
%%% Provide the csv file for event details
% [A,B,~]=readtable('event_details.csv');  % <------------------
% B=B{:};
A = readtable('event_details.csv');
A=table2cell(A);

B=A{:,1};

ye_ev=B(1:4);
    ye_ev=str2double(ye_ev);
        mo_ev=B(6:7);
            mo_ev=str2double(mo_ev);
                da_ev=B(9:10);
                    da_ev=str2double(da_ev);
hh_evi=B(12:13);
    hh_ev=str2double(hh_evi);
        mi_evi=B(15:16);
            mi_ev=str2double(mi_evi);
                ss_evi=B(18:19);
                    ss_ev=str2double(ss_evi);
                        ms_evi=B(21:23);
                            ms_ev=str2double(ms_evi);
lat_ev=A{1,2};
    long_ev=A{1,3};
        dep_ev=A{1,4};
or_time=datetime(ye_ev,mo_ev,da_ev,hh_ev,mi_ev,ss_ev,ms_ev,'TimeZone','UTC'); 
or_time.Format='dd-MM-yyyy HH:mm:ss.SSS';
or_dtnm=datenum(or_time);

%% arrival time calculation
if isfile('arrival_time.txt')==0
    
    if isfile('taut.txt')==1
        hh_or_tim=sprintf('%s:%s:%s.%s',hh_evi,mi_evi,ss_evi,ms_evi);
        arrival_time_calc(hh_or_tim);
else
    end
else
end

end