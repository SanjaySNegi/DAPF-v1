
% Slide_add_new_ver
% This function merge the segments of filtered time series and returns a
% to a single trace.

% Written by: Sanjay. S. Negi (2019)

function [Tr_new,k1]=slide_add_new_ver(inv_pol_mul_11,tbk_r,slid_r,Fs)
% load inv_pol_mul_11.mat; 
% load tbk_r.mat; load slid_r.mat;
    dt=1/Fs;
        qq=inv_pol_mul_11(:,1);
            Tr_new=qq(:,1);
                k1=tbk_r(:,1);
[~,col]=size(inv_pol_mul_11);

% plot(Tr_new)
% return

for ii=1:col-1
%     Tr1=inv_pol_mul_11(:,ii);
    Tr2=inv_pol_mul_11(:,ii+1);
            slid_point=slid_r(ii);
%     k1=tbk_r(:,ii);
    k2=tbk_r(:,ii+1);
    difere1=k1-slid_point;
      [~,ind_m1]=min(abs(difere1));
%             ind_m1=find(k1==slid_point); %%%%%%% index of initial merging point in first segment
    end_point=k1(end);
        difere2=k2-end_point;
            [~,ind_m2] = min(abs(difere2));
%             ind_m2=find(k2==end_point); %%%%%%% index of end merging point in second segment
    
    %%%%% Trace before Overlap %%%%%%
    Tr_b_ovrlp=Tr_new(1:ind_m1-1);
    %%%%% merging Ovelap
    m_tr1=Tr_new(ind_m1:end);
    m_tr2=Tr2(1:ind_m2);
    merg=(m_tr1+m_tr2)/2;
    %%%%% Trace after Overlap  %%%%%%
    Tr_a_ovrlp=Tr2(ind_m2+1:end);

%       plot(merg)
    Tr_new=cat(1,Tr_b_ovrlp,merg,Tr_a_ovrlp);
        k1=(0:dt:(length(Tr_new)-1)/Fs);

  
    
end
end
