clc
clear
%% Generate station-event list
datadir = fullfile(pwd,'DATA');
dirct1=dir(datadir);

stat_lis=dirct1(~ismember({dirct1.name},{'.','..'}));
for ii=1:numel(stat_lis)
stat_nm=stat_lis(ii).name
s_nm=sprintf('%s_event_list.txt',stat_nm);
fid=fopen(s_nm,'w');
stat_fold=fullfile(datadir,stat_nm);
ev_lis=dir(stat_fold);
% 
ev_lis=ev_lis(~ismember({ev_lis.name},{'.','..'}));
numb=numel(ev_lis);
for jj=1:numel(ev_lis)
ev_fold=fullfile(stat_fold,ev_lis(jj).name)
fprintf(fid,'%s\n',ev_fold);
end
fclose(fid)
end
