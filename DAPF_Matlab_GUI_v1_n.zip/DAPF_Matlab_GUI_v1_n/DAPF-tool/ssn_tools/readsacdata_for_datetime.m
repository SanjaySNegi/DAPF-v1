function [out2,tim_dt,Fs,stat]= readsacdata_for_datetime(sacFile)
[head1, head2, head3, data]=sac(sacFile);
% hd = rdSacHead(sacFile);
[SACdata]=sachdr(head1, head2, head3);

dt=head1(1,1);
Fs=1/dt;

ye=head2(1,1);
    jd=head2(1,2);
        hr= head2(1,3);
            mi = head2(1,4);
                sec = head2(1,5);
                    msec = head2(2,1); % micro second
                        sms=sec+msec/1000;

%%% Station info
stla= head1(7,2);
    stlo= head1(7,3);
        stel = head1(7,4);
            stdp = head1(7,5);
                stat=char(head3(1,1:8));
                    stat= stat(find(~isspace(stat)));
                        comp=char(head3(7,17:24));
                            comp= comp(find(~isspace(comp)));
%%% Event Info
evla = head1(8,1);
   evlo = head1(8,2);
        evel = head1(8,3);
            evdp = head1(8,4);
                mag = head1(8,5);
                
                s_inp=sprintf('%4.0f-%2.0fT%02.0f:%02.0f:%06.3f',ye,jd,hr,mi,sms);
infmt='uuuu-D''T''H:m:s.SSS';
fmt='dd-MM-yyyy HH:mm:ss.SSS';
tt_start=datetime(s_inp,'InputFormat',infmt,'Format',fmt);    %%% trace start time in datetime
t_inp=char(tt_start);
k=datenum(t_inp,'dd-mmm-yyyy  hh:MM:ss.fff');
%% create time-series
out2=data;
strt=0;

npts=length(out2);
t_sec=(0:dt:(npts-1)/Fs);   % time series in seconds
format shortg
tot_sec=max(t_sec);   
tt_stop=tt_start + seconds(tot_sec); % trace_stop in datetime
format longg
tim_dt = tt_start:seconds(dt):tt_stop;
tim_dt=tim_dt(:);