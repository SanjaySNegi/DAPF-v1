
% The script 'arrival_time_calc' converts the ouput from Taup arrival time (in seconds)
% to the datetime ( in hh:mm:ss.SSS). It helps in marking the theoretical arrival time 
% of the teleseismic phases on seismogram datetime plot in MATLAB.
% To use arrival_time_calc, phase arrival time information is required (see in
% 'taut.txt' file). The taut.txt contains the same travel time information 
% format (given below) as estimated by Taup program (Crotwell et al., 1998).

%     30.6	  3407.1	    10.0	P	  374.39	   8.824	    30.6	=
%     30.6	  3407.1	    10.0	PcP	  552.19	   2.632	    30.6	=
%     30.6	  3407.1	    10.0	S	  677.66	  15.636	    30.6	=
%     30.6	  3407.1	    10.0	PKiKP	 1003.24	   0.671	    30.6	=
%     30.6	  3407.1	    10.0	ScS	 1011.29	   4.863	    30.6	=
%     30.6	  3407.1	    10.0	SKiKS	 1427.48	   0.746	    30.6	=

% Input- 'taut.txt'
% Output- 'arrival_time.txt'
% Written by: Sanjay. S. Negi (2019)

function arrival_time_calc(origin_ti)
%%%%% ADD seconds to date time

dt = datetime(origin_ti , 'InputFormat', 'HH:mm:ss.SSS' );
dt.Format = 'HH:mm:ss.SSS';

%% Reading Taut file
fullFileName = fullfile(pwd, 'taut.txt');
t = readtable(fullFileName);
l_d=length(t.Var2);
all_phs=t.Var4;
fid=fopen('arrival_time.txt','w');                                                        
for ii=1:l_d 
    
    phs=(t.Var4{ii})
ar_t=(t.Var5(ii));

arrival_time=dt + seconds(ar_t);
c=char(arrival_time);
fprintf(fid,'Phase %s arrival time =%s\n',phs,c);
end
fclose(fid)