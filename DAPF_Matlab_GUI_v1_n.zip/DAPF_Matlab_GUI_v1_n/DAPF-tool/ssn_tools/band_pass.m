%%%%%%%%%% Bandpass filtering with cosine tapering%%%

function filt_trace=band_pass(trace,Fs,order,low_lim,high_lim)
%%%%%%%%%%%%%%%%
trace=rtrend(rmean(trace));
 pt = 0.05;                 % 5 percent of tapering
 tucka1m=tukeywin(length(trace),pt); 
%  tucka1m=tucka1m(:);
 trace =(trace(:).*tucka1m); 
[B,A] = butter(order,[low_lim high_lim]/(Fs/2));
filt_trace=filter(B,A,trace);
  
end
  
