%%%%%%

%% DATA ADAPTIVE POLARIZATION FILTER 
% DAPF_MUL_TAP_PMTM
% This script is a main function file to implement the 
% data-adaptive-polarization-filter(DAPF)[Samson 1981; Du et al., 2000]
% Written by: Sanjay. S. Negi (2019)

%%%%%%%%%%%%
%%
function [Tr_new1,Tr_new2,Tr_new3,tk,Fs,TNOI1,TNOI2]=DAPF_mul_tap_pmtm(zzcomp,nscomp,ewcomp, ...
    K,g,t1,t2,tn1,tn2,phi,fact,dec_rng,pont1,pont2,store_sac,or_dtnm,dwnsmpl,use_land,use_OBS)
warning('off')
%%
%%
tic
%%%%%%%--------------------------------------------------------------
%% Reads and load the sac files

filename={zzcomp nscomp ewcomp};
nfl=numel(filename);

for jj=1:nfl
sacfl= filename{jj};
   [head1, head2, head3, data]=sac(sacfl);
[SACdata]=sachdr(head1, head2, head3);
SAC_old=SACdata;
format long
ye=head2(1,1);
    jd=head2(1,2);
        hr= head2(1,3);
            mi = head2(1,4);
                sec = head2(1,5);
                    msec = head2(2,1); % micro second
                        sms=sec+msec/1000;
                       
                     
%% Station info
                stat1=char(head3(1,1:8));
                    stat= stat1(find(~isspace(stat1)));
                        comp=char(head3(7,17:24));
                            comp= comp(find(~isspace(comp)));
                            stla=head1(7,2);
                            stlo=head1(7,3);
                            stel=head1(7,4);
%% Event info
evla=head1(8,1);
evlo=head1(8,2);
evdp=head1(8,4);
%%
s_inp=sprintf('%4.0f-%2.0fT%02.0f:%02.0f:%06.3f',ye,jd,hr,mi,sms);
infmt='uuuu-D''T''H:m:s.SSS';
fmt='dd-MM-yyyy HH:mm:ss.SSS';
tt_start_old=datetime(s_inp,'InputFormat',infmt,'Format',fmt);    %%% trace start time in datetime

t_inp_old=char(tt_start_old);
k=datenum(t_inp_old,'dd-mmm-yyyy  HH:MM:ss.fff');

%%%%
sig1(:,jj)=data;

end
 
%% arc distance calculation
% disp(lat_ev);  disp(long_ev);  disp(dep_ev);  disp(OBS);
arclength_calc(evla,evlo,evdp,stla,stlo,stat)

%% Raw data and time series
% comp1=compi(1); comp2=compi(2); comp3=compi(3);
comp1='Z'; comp2='N'; comp3='E';
z_cmp=sig1(:,1); 
 n_cmp=sig1(:,2);
   e_cmp=sig1(:,3);

%% create time-series
% dt_old=round(head1(1,1)*100)/100;
dt_old=round(head1(1,1),3);
Fs_old=1/dt_old;

FSO=Fs_old;

strt=0;
npts_old=length(data);
t_sec_old=(0:dt_old:(npts_old-1)/Fs_old);   % time series in seconds

format shortg
tot_sec_old=max(t_sec_old);   
tt_stop_old=tt_start_old + seconds(tot_sec_old); % trace_stop in datetime
format longg
tim_dt_old = tt_start_old:seconds(dt_old):tt_stop_old;
tim_dt_old=tim_dt_old(:);
tim_dtnum_old=datenum(tim_dt_old);

 %% Decide range of data
if dec_rng==1
    
    
sec2pont1=pont1*Fs_old+1;
sec2pont2=pont2*Fs_old+1;

    z_cmp=z_cmp(sec2pont1:sec2pont2);
    n_cmp=n_cmp(sec2pont1:sec2pont2);
    e_cmp=e_cmp(sec2pont1:sec2pont2);
    
   
npts_old=length(z_cmp);
t_sec_old=(0:dt_old:(npts_old-1)/Fs_old);   % time series in seconds
 
format shortg
% tot_sec_old=max(t_sec_old);   
% tt_stop_old=tt_start_old + seconds(tot_sec_old); % trace_stop in datetime
format longg
% tim_dt_old = tt_start_old:seconds(dt_old):tt_stop_old;
% return
tim_dt_old=tim_dt_old(sec2pont1:sec2pont2);
tim_dt_old=tim_dt_old(:);
tim_dtnum_old=datenum(tim_dt_old);

%% tt_start changes here
tt_start_old=tim_dt_old(1);
end

if use_land==1
    filt_trace1=z_cmp;
        filt_trace2=n_cmp;
            filt_trace3=e_cmp;
            orint=0;
else
    if use_OBS==1
        
    phi=360-phi;
deg_to_rad=pi/180;
cphi=cos(phi*deg_to_rad);
sphi=sin(phi*deg_to_rad);
     filt_trace1=z_cmp;
        filt_trace2=cphi*n_cmp+sphi*e_cmp;
            filt_trace3=-sphi*n_cmp+cphi*e_cmp;
            orint=1;
           
    end
end
    
%% Data Downsampling condition
%%% Choose downsampling either by decimate function or resample function
%%% dmd=1 for decimate and dmd=2 for resample.
%%% Both function provides similar result but resample function encounter
%%% problem in Matlab R2018b version.
%%% Therefore we utilize decimate for downsampling the data.

dmd=1;

if dwnsmpl==1
    p=fact;
        q=Fs_old;
            ks=(p/q)*Fs_old;
    if dmd==1
        facto=Fs_old/fact;
        %%%% DECIMATE
    filt_trace1=decimate(filt_trace1,facto,'fir');
         filt_trace2=decimate(filt_trace2,facto,'fir'); 
              filt_trace3=decimate(filt_trace3,facto,'fir'); 
    elseif dmd==2
        %%%% RESAMPLE           
    filt_trace1=resample(filt_trace1,p,q);
          filt_trace2=resample(filt_trace2,p,q); 
                 filt_trace3=resample(filt_trace3,p,q); 
    end

%%%%%% create time-series

Fs=fact;
dt=1/Fs;
strt=0;
npts=length(filt_trace1);
t_sec=(0:dt:(npts-1)/Fs);   % time series in seconds

format shortg
tot_sec=max(t_sec);   
tt_stop=tt_start_old + seconds(tot_sec); % trace_stop in datetime
format longg
tim_dt = tt_start_old:seconds(dt):tt_stop;
tim_dt=tim_dt(:);
tim_dtnum=datenum(tim_dt);

else

filt_trace1=z_cmp;
        filt_trace2=n_cmp;
            filt_trace3=e_cmp;
   Fs=Fs_old; dt=dt_old;
 npts=npts_old; t_sec=t_sec_old;
 tot_sec=tot_sec_old;   tt_stop=tt_stop_old;
 tim_dt=tim_dt_old(:);
 tim_dtnum=tim_dtnum_old;
 
end

%%  Provide Filter parameters
nw=(K+1)/2;
tdiff=t2-t1; %%% (seconds)

%% Mean and detrend data
filt_trace1=rtrend(rmean(filt_trace1)); %comp1='Z';
    filt_trace2=rtrend(rmean(filt_trace2)); %comp2='N';
        filt_trace3=rtrend(rmean(filt_trace3)); %comp3='E';
        
%% Insert NOISE range in seconds %%Input
ndif=tn2-tn1;

        
%% Considering resampled data
l_out=length(filt_trace1);
     l_S=tdiff*Fs;
     
%%   NOISE-SECTION
%%%%%%%%% Selected noise window
            l_N=ndif*Fs; %%%% the length of window for noise (in seconds)
            t_noi=t_sec(tn1*Fs+1:tn2*Fs); %%%%% time window will be same for all components
            timedate_noi=tim_dt(tn1*Fs+1:tn2*Fs);
            TNOI1=timedate_noi(1);
            TNOI2=timedate_noi(end);
          
Nos1=filt_trace1(tn1*Fs+1:tn2*Fs);  %%%%% component 1 selected as per window
    Nos2=filt_trace2(tn1*Fs+1:tn2*Fs);
        Nos3=filt_trace3(tn1*Fs+1:tn2*Fs);
            Nos1=Nos1(:); Nos2=Nos2(:); Nos3=Nos3(:);
%% % % % % Plot the data first
% % if on_plot==1
% % fig6=figure(6);
% % subplot(3,1,1); plot(tim_dt,filt_trace1); title(comp1); hold on; plot(timedate_noi,Nos1); title(comp1)
% % subplot(3,1,2);plot(tim_dt,filt_trace2); title(comp2);hold on; plot(timedate_noi,Nos2); title(comp2)
% % subplot(3,1,3);plot(tim_dt,filt_trace3);title(comp3);hold on;plot(timedate_noi,Nos3);title(comp3)
% % orient(fig6,'landscape')
% % set(gcf,'Position',[100 100 1200 700])
% % %------------------------------------------
% % else
% Print parameters once confirmed
 if dec_rng==1
     m=sprintf(' K=%d\n g=%d\n t1=%d\n t2=%d\n tn1=%d\n tn2=%d\n data considered (in secs)=%d to %d\n Is orientation applied=%d phi=%6.2f\n'...
    ,K,g,t1,t2,tn1,tn2,pont1,pont2,orint,360-phi);
 else
m=sprintf(' K=%d\n g=%d\n t1=%d\n t2=%d\n tn1=%d\n tn2=%d\n Is orientation applied=%d , phi=%6.2f\n'...
    ,K,g,t1,t2,tn1,tn2,orint,360-phi);
 end
fid=fopen('Input_multi_parameters.par','w');
fprintf(fid,m);
fclose(fid);


%% Noise spectral density matrix

[npxx1]=pmtm(Nos1,nw);
    [npxx2]=pmtm(Nos2,nw);
        [npxx3]=pmtm(Nos3,nw);
            n_zw=horzcat(npxx1,npxx2,npxx3);
  specmat=1;      % if specmat=1 then apply hermitian conjugate; if specmat=2 then apply svd;

 if specmat==1
         M_conjN=ctranspose(n_zw);
         N_MTSDM=mtimes(M_conjN,n_zw)/K;
         
 elseif specmat==2
         N_MTSDM = svdgui(n_zw);
         N_MTSDM=N_MTSDM(1:3,:);
 end
          

%% Applying adaptive truncation on time series on the basis of polarization
slid_1=0;
ii=0;

while 1
   
    ii=ii+1;
kk1=(t1*Fs)+1;
kk2=(t2*Fs);

tr1=rtrend(rmean(filt_trace1(((t1*Fs)+1):(t2*Fs))));  %%%  slicing down the overlapped traces according to truncation
    tr2=rtrend(rmean(filt_trace2(((t1*Fs)+1):(t2*Fs))));
        tr3=rtrend(rmean(filt_trace3(((t1*Fs)+1):(t2*Fs))));
           ltr1=length(tr1);
                lcomp=tdiff*Fs;
                tbk=t_sec(kk1:kk2);
if ltr1<lcomp
    di=abs(lcomp-ltr1);
tr1=rtrend(rmean(filt_trace1(((t1*Fs)+1):(t2*Fs)+di)));  %%%  slicing down the overlapped traces according to truncation
  tr2=rtrend(rmean(filt_trace2(((t1*Fs)+1):(t2*Fs)+di)));
    tr3=rtrend(rmean(filt_trace3(((t1*Fs)+1):(t2*Fs)+di)));
    kk1=(t1*Fs)+1;
    kk2=(t2*Fs)+di;
    tbk=t_sec(kk1:kk2);
end

tr1=tr1(:);tr2=tr2(:);tr3=tr3(:);

sel_tr1(:,ii)=tr1; %%%  saving traces in a matrix
    sel_tr2(:,ii)=tr2;
         sel_tr3(:,ii)=tr3;          
 tbk_r(:,ii)=tbk;             

%%%%% polarization estimate from signal windowing
[spx1]=pmtm(tr1,nw);
    [spx2]=pmtm(tr2,nw);
        [spx3]=pmtm(tr3,nw);

spx11=spx1;
spx22=spx2;
spx33=spx3;

zw=horzcat(spx11,spx22,spx33);
    if specmat==1
    M_conj=ctranspose(zw);
    S_MTSDM=mtimes(M_conj,zw)/K;  %%% signal spectral matrix
    MTSDM=mtimes(S_MTSDM,inv(N_MTSDM)); %%% decolvolving Noise from signal spectra 
%      U2=MTSDM;
    [~,U2,~]=eig(MTSDM);   %%%% eigen of the modifies spectral matrix
    elseif specmat==2
    S_MTSDM = svdgui(zw);
    S_MTSDM=S_MTSDM(1:3,:);
    MTSDM=mtimes(S_MTSDM,inv(N_MTSDM)); %%% decolvolving Noise from signal spectra 
    U2=MTSDM;
    end      
%%
ncomp=3; %%% number of components
num=(ncomp*trace(U2.^2))-(trace(U2))^2;   %%%% Trace operation
    den=(ncomp-1)*(trace(U2))^2; 
        pol=(num/den);  % polarization factor estimate
pol_ar(ii)=pol; % store polarization value of each signal segment

%% application of adaptive truncation
[valm,indm]=adapt_trunc(pol,g,K,l_S,l_out,dt);  %%%% finding truncation point

indm1(ii)=indm;
    m=(l_S-1-(2*indm));     %%%%% the amount of overlap in terms of points not in seconds
        slide=(l_S-m)*dt; %%%%%%% converting overlap to slide in seconds
            slid_1=slid_1+slide;
                slid_r(ii)=slid_1;

t1=slid_1;
    t2=slid_1+(l_S*dt);

if t2>max(t_sec)
 break;
end

end

%%
[~, num_stps]= size(sel_tr1);
for hh=1:num_stps

tr11=sel_tr1(:,hh);
    tr22=sel_tr2(:,hh);
        tr33=sel_tr3(:,hh);
tr11=tr11(:);
  tr22=tr22(:);
      tr33=tr33(:);
             
% % % % %%%% multitaper fft
 [~,avg_z1,dps_seq,num_seq,seq_length]=mul_tap_fft(tr11,nw,dt);
     [~,avg_z2,~,~,~]=mul_tap_fft(tr22,nw,dt);
         [~,avg_z3,~,~,~]=mul_tap_fft(tr33,nw,dt);
dps=zeros(seq_length,1);

for gg=1:K

dps=dps+dps_seq(:,gg);
end
dps=dps/K;

 Rtr_Tr1=ifft((pol_ar(hh))^g*avg_z1)*Fs;
        Rtr_Tr2=ifft((pol_ar(hh))^g*avg_z2)*Fs;
            Rtr_Tr3=ifft((pol_ar(hh))^g*avg_z3)*Fs;
            
           
     inv_pol_mul_11(:,hh)=Rtr_Tr1./dps;
        inv_pol_mul_12(:,hh)=Rtr_Tr2./dps;
            inv_pol_mul_13(:,hh)=Rtr_Tr3./dps;

end


%% The files saved in '.mat' format for plotting

save('filt_trace1.mat','filt_trace1');
    save('filt_trace2.mat','filt_trace2');
        save('filt_trace3.mat','filt_trace3');
            save('comp1.mat','comp1');
                save('comp2.mat','comp2');
                    save('comp3.mat','comp3');
                    save('t_sec.mat','t_sec');
               save('tim_dt.mat','tim_dt');
            save('Fs.mat','Fs');
         save('pol_ar.mat','pol_ar');
      save('tbk_r.mat','tbk_r');
   save('slid_r.mat','slid_r');

% msgbox('Processing finished');

%% Retreival of time series after DAPF

[Tr_new1,~]=slide_add_new_ver(inv_pol_mul_11,tbk_r,slid_r,Fs); save('Tr_new1.mat','Tr_new1');
[Tr_new2,~]=slide_add_new_ver(inv_pol_mul_12,tbk_r,slid_r,Fs); save('Tr_new2.mat','Tr_new2');
[Tr_new3,~]=slide_add_new_ver(inv_pol_mul_13,tbk_r,slid_r,Fs); save('Tr_new3.mat','Tr_new3');


%% Time series for plotting 
tk=tim_dt(1:length(Tr_new1));

%% To save output data in sac format

if store_sac==1
    
disp('Started writing DAPF sac output file ...');

%% origin time info
% chk_tim=datetime('2018-08-05 11:45:38.630','InputFormat','yyyy-MM-dd hh:mm:ss.SSS');
% chk_tim.Format='dd-MM-yyyy hh:mm:ss.SSS';
chk_tim=datenum(tim_dt(1));
    t11=datevec(or_dtnm);
        t22=datevec(chk_tim);
            time_diff = round(-1*(etime(t22,t11)));

%% SAVE in SAC FORMAT
SACdata.data.trclen=npts;
    SACdata.times.delta=dt;
        SACdata.times.o=time_diff;   %% -360;   %%%%%%%% Important to check the cut data and change accordingly
            SACdata.times.e=npts;
%                 disp(SACdata.times.o);
%%
[hk1,mk1,sk1]=hms(tt_start_old);

sk1s=floor(sk1);
    sk1ms=sk1-sk1s;
        SACdata.event.nzhour=hk1;
            SACdata.event.nzmin=mk1;
                SACdata.event.nzsec=sk1s;
                    SACdata.event.nzmsec=sk1ms;
% disp(SACdata.event.nzmsec);
    sec1=num2str(sec+msec/1000);
%% Vertical Component
disp('Writing Z- sac output file ...')
    SACdata.station.kcmpnm='BHZ';
        s_inp1=sprintf('%4.0f.%2.0f.%02.0f.%02.0f.%s0.SA.%s.01.BHZ.PF.SAC',ye,jd,hr,mi,sec1,stat); 
            writeSAC(s_inp1,SACdata,Tr_new1);
%% NS- Component
disp('Writing N- sac output file ...')
    SACdata.station.kcmpnm='BHN';
        s_inp2=sprintf('%4.0f.%2.0f.%02.0f.%02.0f.%s0.SA.%s.01.BHN.PF.SAC',ye,jd,hr,mi,sec1,stat); 
            writeSAC(s_inp2,SACdata,Tr_new2);

%% EW- Component
disp('Writing S- sac output file ...')
    SACdata.station.kcmpnm='BHE';
        s_inp3=sprintf('%4.0f.%2.0f.%02.0f.%02.0f.%s0.SA.%s.01.BHE.PF.SAC',ye,jd,hr,mi,sec1,stat); 
            writeSAC(s_inp3,SACdata,Tr_new3);
                movefile '*PF.SAC*' 'DAPF_Result'
else 
    disp('Output not stored in SAC file ...');

end

toc
end




















