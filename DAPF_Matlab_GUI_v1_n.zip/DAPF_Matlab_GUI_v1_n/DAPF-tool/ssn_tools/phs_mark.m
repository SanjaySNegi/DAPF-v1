function phs_mark(tim_dt)
hold on;
%% Phase read


k=tim_dt(1);
ye=year(k);mn=month(k);dd=day(k);
fullFileName = fullfile(pwd, 'arrival_time.txt');

if isfile(fullFileName)==1
    
t = readtable(fullFileName);
% % % %% To display time arrival info
% % % dis_k=t;
% % % hd={'Phase','arrivaltime'}; 
% % % dis_k.Properties.VariableNames=hd; % setting the second row as header 
% % % disp(dis_k)
%%

l_d=length(t.Var2);
for ii=1:l_d
    ph_tm=(t.Var2(ii));
        [hh,mm,ss]=hms(ph_tm);
    tMark=datetime(ye,mn,dd,hh,mm,ss);
%    phase_time= datetime(t.Var2(ii));
%    tMark = datetime(phase_time); % Time to mark by a vertical line
   plot([tMark tMark], ylim,'--k');
   
end
else
    return
end

