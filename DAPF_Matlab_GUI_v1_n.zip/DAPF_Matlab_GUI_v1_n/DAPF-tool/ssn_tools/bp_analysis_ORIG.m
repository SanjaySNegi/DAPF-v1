%% Function to plot and save the figure 
%%% OUTPUT -
% a- Plot and save 3 component Raw data (Fig 1) as PDF,
% b- Plot and save 3 component bandpass filtered RAW data (Fig 2)as PDF,
% c- Plot and save 3 component DAPF data (Fig 3) as PDF, 
% d- Plot and save 3 component DAPF data (Fig 4) as PDF, 
% e- Plot of estimated polarization Fig(5),
% polarization filtered and bandpass filter applied trace applied 
% DAPF_INP_PAR
% This script facilitates the user to input the parameters required to 
% successfully apply the data-adaptive-polarization-filter(DAPF)[Samson 1981; Du et al., 2000]
% using MATLAB Version: (R2018b)
%%%%%%%%%%%%



function bp_analysis_ORIG(lml,hml,order,tick_frequency) 

% if exist('MAT_files', 'dir')
% %      upUpFolder = fileparts(fileparts(pwd));
% % % go into another folder
% folder = fullfile(pwd,'MAT_files'); %'MAT_files');
% 
% D = dir(folder);
% D=D(~ismember({D.name},{'.','..'}));
% 
% for k = 1:numel(D)
%     load(D(k).name);
% end
% end
load 'Fs.mat'; load 'tim_dt.mat';
load 'comp1.mat';load 'comp2.mat'; load 'comp3.mat';
%%%%% Loading original trace
load 'filt_trace1.mat'; load 'filt_trace2.mat'; load 'filt_trace3.mat';
%%%%% loading AfpPFR trace
load 'Tr_new1.mat'; load 'Tr_new2.mat'; load 'Tr_new3.mat';
load 'pol_ar.mat';
% load 'z_cmp.mat'; load 'n_cmp.mat'; load 'e_cmp.mat';

% rp1=max(findpeaks(filt_trace1)); 
% rp2=max(findpeaks(filt_trace2)); 
% rp3=max(findpeaks(filt_trace3));
% 
% fp1=max(findpeaks(Tr_new1));
% fp2=max(findpeaks(Tr_new2));
% fp3=max(findpeaks(Tr_new3));


%%
% % % For Filtering; filt_apl = 0 (rawdata); =1 (lowpass filtering); =2
% (highpass filtering); =3 (bandpass-filtering)

low_lim=lml;
high_lim=hml;


%% Plot the phase markers
% lm=1E2;
% [OT_ar,yax1]=time_marker(2012,02,03,03,46,21,lm);
% [OT_ar,yax1]=time_marker(2012,02,03,04,00,00,lm);

%%
% z_cmp=z_cmp(1:length(Tr_new1));
% n_cmp=n_cmp(1:length(Tr_new1));
% e_cmp=e_cmp(1:length(Tr_new1));

filt_trace1=filt_trace1(1:length(Tr_new1));
filt_trace2=filt_trace2(1:length(Tr_new1));
filt_trace3=filt_trace3(1:length(Tr_new1));

%% %%%% time length
 tim=tim_dt(1:length(Tr_new1));
% save('tim.mat','tim');

%%
% tick_frequency=1500;
tick1=tim(1:tick_frequency:end);

%% Plot raw data with noise 
dat_pro1=sprintf('%s - Raw trace',comp1);
dat_pro2=sprintf('%s - Raw trace',comp2);
dat_pro3=sprintf('%s - Raw trace',comp3);
disp('Saving Figure 1/5 ...')
fig2=figure('visible', 'off');
subplot(3,1,1); plot(tim,filt_trace1,'k'); title(dat_pro1)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,2);plot(tim,filt_trace2,'k'); title(dat_pro2)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,3);plot(tim,filt_trace3,'k');title(dat_pro3)
    set(gca, 'xtick', tick1);
datetick('x', 'HH:MM:SS', 'keepticks');
% return
%% Amplitudes
rp4=max(findpeaks(filt_trace1)); txtr4 = sprintf('%3.1e', rp4);
rp5=max(findpeaks(filt_trace2)); txtr5 = sprintf('%3.1e', rp5);
rp6=max(findpeaks(filt_trace3)); txtr6 = sprintf('%3.1e', rp6);
%%

orient(fig2,'landscape')
set(gcf,'Position',[100 100 1200 700])
saveas(gcf,'2_Raw_NOISE_plot.pdf')



%% Plot raw data with noise and Bandpassed
[ filt_trace1_bp, filt_trace2_bp,filt_trace3_bp]=filt_analysis(filt_trace1, ...
            filt_trace2,filt_trace3,Fs,low_lim,high_lim,order);
dat_pro1=sprintf('%s - Raw-bandpass (%5.2f - %5.2f)Hz',comp1,lml,hml);
dat_pro2=sprintf('%s - Raw-bandpass (%5.2f - %5.2f)Hz',comp2,lml,hml);
dat_pro3=sprintf('%s - Raw-bandpass (%5.2f - %5.2f)Hz',comp3,lml,hml);
disp('Saving Figure 2/5 ...')

fig3=figure('visible', 'off');
subplot(3,1,1); plot(tim,filt_trace1_bp,'k'); title(dat_pro1)
    phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,2);plot(tim,filt_trace2_bp,'k'); title(dat_pro2)
phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,3);plot(tim,filt_trace3_bp,'k');title(dat_pro3)
phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
datetick('x', 'HH:MM:SS', 'keepticks');
% return
%% Amplitudes
rp7=max(findpeaks(filt_trace1_bp)); txtr7 = sprintf('%3.1e', rp7);
rp8=max(findpeaks(filt_trace2_bp)); txtr8 = sprintf('%3.1e', rp8);
rp9=max(findpeaks(filt_trace3_bp)); txtr9 = sprintf('%3.1e', rp9);
%%

orient(fig3,'landscape')
set(gcf,'Position',[100 100 1200 700])
saveas(gcf,'3_Raw_NOISE_BP_plot.pdf')


%% DAPF FILTERED TRACE
dat_pro1=sprintf('%s - DAPF trace',comp1);
dat_pro2=sprintf('%s - DAPF trace',comp2);
dat_pro3=sprintf('%s - DAPF trace',comp3);
disp('Saving Figure 3/5 ...')
fig4=figure('visible', 'off');
subplot(3,1,1); plot(tim,Tr_new1,'k'); title(dat_pro1)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,2);plot(tim,Tr_new2,'k'); title(dat_pro2)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,3);plot(tim,Tr_new3,'k');title(dat_pro3)
    set(gca, 'xtick', tick1);
datetick('x', 'HH:MM:SS', 'keepticks');

%% Amplitudes
rp10=max(findpeaks(Tr_new1)); txtr10 = sprintf('%3.1e', rp10);
rp11=max(findpeaks(Tr_new2)); txtr11 = sprintf('%3.1e', rp11);
rp12=max(findpeaks(Tr_new3)); txtr12 = sprintf('%3.1e', rp12);
%%

orient(fig4,'landscape')
set(gcf,'Position',[100 100 1200 700])
saveas(gcf,'4_DAPF_plot.pdf')

%% Band pass filtering of DAPF
[ Tr_new1_bp, Tr_new2_bp,Tr_new3_bp]=filt_analysis(Tr_new1,Tr_new2,Tr_new3,Fs,low_lim,high_lim,order);
dat_pro1=sprintf('%s - DAPF-bandpass (%5.2f - %5.2f)Hz',comp1,lml,hml);
dat_pro2=sprintf('%s - DAPF-bandpass (%5.2f - %5.2f)Hz',comp2,lml,hml);
dat_pro3=sprintf('%s - DAPF-bandpass (%5.2f - %5.2f)Hz',comp3,lml,hml);
disp('Saving Figure 4/5 ...')
fig5=figure('visible', 'off');
subplot(3,1,1); plot(tim,Tr_new1_bp,'k'); title(dat_pro1)
phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,2);plot(tim,Tr_new2_bp,'k'); title(dat_pro2)
phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
    datetick('x', 'HH:MM:SS', 'keepticks');
subplot(3,1,3);plot(tim,Tr_new3_bp,'k');title(dat_pro3)
phs_mark(tim_dt)
    set(gca, 'xtick', tick1);
datetick('x', 'HH:MM:SS', 'keepticks');

%% Amplitudes
rp13=max(findpeaks(Tr_new1_bp)); txtr13 = sprintf('%3.1e', rp13);
rp14=max(findpeaks(Tr_new2_bp)); txtr14 = sprintf('%3.1e', rp14);
rp15=max(findpeaks(Tr_new3_bp)); txtr15 = sprintf('%3.1e', rp15);
%%

orient(fig5,'landscape')
set(gcf,'Position',[100 100 1200 700])
saveas(gcf,'5_DAPF_BP_plot.pdf')

%% Total Amps
%% Plotting the estimated polarization
disp('Saving Figure 5/5 ...')
fig6=figure ('visible', 'off');
plot(pol_ar,'--ok')
xlabel('Number of Segments')
ylabel('Polarization factor (P)')
title('Adaptive Polarization Estimate')
orient(fig6,'landscape')
set(gcf,'Position',[100 100 1200 700])

%% Peak to Peak Amplitude of each trace
amps=[txtr4;txtr5; txtr6;txtr7; txtr8;txtr9; ...
    txtr10;txtr11; txtr12; txtr13; txtr14; txtr15];
s0=sprintf('\nThe peak amplitudes of 3 component seismograms\n---------------------------------------------\n');
s1=sprintf('Data        peak-Z         peak-N        peak-E');
s2=sprintf('Input       %s        %s       %s',txtr4,txtr5,txtr6);
s3=sprintf('DAPF        %s        %s       %s',txtr7,txtr8,txtr9);
s4=sprintf('bp-Input    %s        %s       %s',txtr10,txtr11,txtr12);
s5=sprintf('bp-DAPF     %s        %s       %s',txtr13,txtr14,txtr15);

peakamps=sprintf('%s%s\n%s\n%s\n%s\n%s\n',s0,s1,s2,s3,s4,s5);
fprintf(peakamps);
fid12=fopen('peak_amps.amp','w');
fprintf(fid12,peakamps);
fclose(fid12);

%disp(amps)
% fid=fopen('amps.txt','w');
% fprintf(fid,'Maximum amplitude %s',amps);
% fclose(fid);
%% Move all figures to DAPF_result folder
 movefile '*.pdf' 'DAPF_Result'
 movefile '*.amp' 'DAPF_Result'
%     disp ('No mat file exists... Please RUN DAPF')
end
    



