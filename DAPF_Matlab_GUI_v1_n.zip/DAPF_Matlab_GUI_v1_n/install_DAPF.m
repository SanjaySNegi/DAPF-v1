%% Install DAPF
clc
clear
pth=genpath('DAPF-tool');
addpath(pth)
savepath
disp('DAPF installed !!!')
disp('To start with DAPF proceed to DAPF-tool !!!')